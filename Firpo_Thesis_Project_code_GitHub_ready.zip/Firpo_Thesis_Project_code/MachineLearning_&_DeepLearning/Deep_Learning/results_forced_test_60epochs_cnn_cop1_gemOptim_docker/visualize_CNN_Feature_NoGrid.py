import os
import cv2
import pydicom
import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# ==============================================================================
# CONFIGURAZIONE DEI PERCORSI E PARAMETRI
# ==============================================================================
WEIGHTS_PATH = r"C:/Users/gibog/Desktop/tesi/output_codici/results_forced_test_60epochs_cnn_cop1_gemOptim_docker/resnet_mri_artifacts.pth"
DICOM_DIR = r"C:/Users/gibog/Desktop/tesi/dataset/DicomForValidation"
OUTPUT_PLOTS_DIR = r"C:/Users/gibog/Desktop/tesi/output_codici/results_forced_test_60epochs_cnn_cop1_gemOptim_docker/individual_plots"

os.makedirs(OUTPUT_PLOTS_DIR, exist_ok=True)

IMG_SIZE = 256
NUM_CLASSES = 4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def resnet18_mri():
    model = models.resnet18(weights=None)
    model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    model.fc = nn.Linear(model.fc.in_features, NUM_CLASSES)
    return model

def preprocess_dicom(dicom_path):
    ds = pydicom.dcmread(dicom_path)
    img = ds.pixel_array.astype(np.float32)

    p_low, p_high = np.percentile(img, (1, 99))
    img = np.clip(img, p_low, p_high)
    if p_high > p_low:
        img = (img - p_low) / (p_high - p_low)
    else:
        img = np.zeros_like(img)

    img_resized = cv2.resize(img, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)
    tensor = torch.tensor(img_resized, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
    return tensor, img_resized

# ==============================================================================
# ESTRAZIONE FEATURE FINI + INFERENZA PROBABILITÀ E SALVATAGGIO SINGOLO
# ==============================================================================
def inspect_fine_artifacts(dicom_filename):
    dicom_path = os.path.join(DICOM_DIR, dicom_filename)
    if not os.path.exists(dicom_path):
        print(f"File non trovato: {dicom_path}")
        return

    model = resnet18_mri()
    model.load_state_dict(torch.load(WEIGHTS_PATH, map_location=DEVICE))
    model.to(DEVICE)
    model.eval()

    input_tensor, original_img = preprocess_dicom(dicom_path)
    input_tensor = input_tensor.to(DEVICE)

    # Hook per catturare conv1 e layer1
    activations = {}
    def hook_fn(name):
        def hook(mod, inp, out):
            activations[name] = out.detach()
        return hook

    model.conv1.register_forward_hook(hook_fn('conv1'))
    model.layer1.register_forward_hook(hook_fn('layer1'))

    with torch.no_grad():
        logits = model(input_tensor)
        probs = F.softmax(logits, dim=1).squeeze().cpu().numpy()
        pred_class = int(np.argmax(probs))

    conv1_acts = activations['conv1'].squeeze().cpu().numpy()   # Shape: (64, 128, 128)
    layer1_acts = activations['layer1'].squeeze().cpu().numpy() # Shape: (64, 128, 128)

    # Selezione canali Conv1 a massima varianza
    channel_variances = np.var(conv1_acts, axis=(1, 2))
    sorted_channels = np.argsort(channel_variances)[::-1]
    top_channels = sorted_channels[:3]

    # Mappa aggregata bordi fini (Layer 1)
    fine_edges_map = np.max(np.abs(layer1_acts), axis=0)
    fine_edges_map = cv2.resize(fine_edges_map, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_CUBIC)

    # Normalizzazione mappa per overlay
    norm_fine = (fine_edges_map - fine_edges_map.min()) / (fine_edges_map.max() - fine_edges_map.min() + 1e-6)
    edge_overlay = cv2.applyColorMap(np.uint8(255 * norm_fine), cv2.COLORMAP_TURBO)
    edge_overlay = cv2.cvtColor(edge_overlay, cv2.COLOR_BGR2RGB) / 255.0
    blended = 0.6 * np.stack([original_img]*3, axis=-1) + 0.4 * edge_overlay

    # Profilo 1D riga mediana
    mid_row = original_img[IMG_SIZE // 2, :]

    base_name = os.path.splitext(dicom_filename)[0]

    # ==============================================================================
    # SALVATAGGIO IMMAGINI SINGOLE
    # ==============================================================================

    # 1. Immagine Originale con linea di campionamento
    plt.figure(figsize=(6, 6))
    plt.imshow(original_img, cmap='gray')
    plt.axhline(IMG_SIZE // 2, color='red', linestyle='--', alpha=0.7, label='Linea Profilo')
    plt.title("Originale Preprocessata")
    plt.legend(loc='lower left', fontsize=8)
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_1_originale.png"), dpi=300)
    plt.close()

    # 2. Istogramma delle Probabilità Classi
    plt.figure(figsize=(6, 6))
    colors = ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71']
    bars = plt.bar([0, 1, 2, 3], probs, color=colors, edgecolor='black', alpha=0.85)
    plt.xticks([0, 1, 2, 3])
    plt.xlabel("Classe")
    plt.ylabel("Probabilità")
    plt.title(f"Predizione: Classe {pred_class} ({probs[pred_class]*100:.1f}%)")
    plt.ylim(0, 1.05)
    plt.grid(axis='y', linestyle=':', alpha=0.5)
    for bar, p in zip(bars, probs):
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2.0, yval + 0.02, f"{p*100:.1f}%", ha='center', va='bottom', fontsize=8, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_2_probabilita.png"), dpi=300)
    plt.close()

    # 3. Mappa Bordi Fini e Discontinuità (Layer 1)
    plt.figure(figsize=(6, 6))
    im = plt.imshow(fine_edges_map, cmap='magma')
    plt.title("Mappa Bordi Fini (Layer 1)")
    plt.colorbar(im, fraction=0.046, pad=0.04)
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_3_mappa_bordi.png"), dpi=300)
    plt.close()

    # 4. Sovrapposizione Doppi Bordi / Banding
    plt.figure(figsize=(6, 6))
    plt.imshow(np.clip(blended, 0, 1))
    plt.title("Highlight Doppi Bordi / Banding")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_4_overlay.png"), dpi=300)
    plt.close()

    # 5. Profilo 1D Orizzontale per Rilevamento Oscillazioni
    plt.figure(figsize=(6, 5))
    plt.plot(mid_row, label='Intensità Pixel', color='black', alpha=0.5)
    plt.plot(norm_fine[IMG_SIZE // 2, :], label='Risposta Layer 1', color='crimson', linewidth=1.5)
    plt.title("Profilo Orizzontale (Banding)")
    plt.xlabel("Pixel X")
    plt.ylabel("Ampiezza")
    plt.legend(loc='upper right', fontsize=8)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_5_profilo_1d.png"), dpi=300)
    plt.close()

    # 6, 7, 8. Tre canali più rilevanti di Conv1
    for idx, ch in enumerate(top_channels):
        plt.figure(figsize=(6, 6))
        f_map = cv2.resize(conv1_acts[ch], (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_NEAREST)
        plt.imshow(f_map, cmap='bone')
        plt.title(f"Conv1 - Filtro #{ch}\n(Dettaglio Direzionale)")
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_PLOTS_DIR, f"{base_name}_6_conv1_filtro_{ch}.png"), dpi=300)
        plt.close()

    print(f"[INFO] Tutte le immagini singole per '{dicom_filename}' sono state salvate in: {OUTPUT_PLOTS_DIR}")

if __name__ == "__main__":
    inspect_fine_artifacts("4165.DCM")