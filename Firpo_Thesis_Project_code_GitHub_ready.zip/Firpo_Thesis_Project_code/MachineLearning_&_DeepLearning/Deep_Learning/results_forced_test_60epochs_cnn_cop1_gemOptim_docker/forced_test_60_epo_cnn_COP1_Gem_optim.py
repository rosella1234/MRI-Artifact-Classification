import os
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import pydicom
import torch
import torchvision.transforms as T
from sklearn.metrics import classification_report, cohen_kappa_score, confusion_matrix
from sklearn.model_selection import train_test_split
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models

# ==========================================
# CONFIGURAZIONE
# ==========================================
BASE_DIR = Path(__file__).resolve().parent

EXCEL_PATH = BASE_DIR / "dataset" / "Classification.xlsx"
DICOM_DIR = BASE_DIR / "dataset" / "images"
NPY_DIR = BASE_DIR / "dataset" / "npyCOP1GEMNOGRAD"

# Percorso al file con gli ID del test set del Machine Learning
ML_TEST_IDS_PATH = BASE_DIR / "dataset" / "ml_test_ids.xlsx"

OUTPUT_DIR = BASE_DIR / "output_codici" / "results_CNN_FixedTestSet"

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(NPY_DIR, exist_ok=True)

IMG_SIZE = 256
BATCH_SIZE = 16
NUM_EPOCHS = 60
LR = 1e-4
NUM_CLASSES = 4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ==========================================
# RESNET18 MRI
# ==========================================
def resnet18_mri():
    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)

    orig_conv1 = model.conv1
    new_conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    with torch.no_grad():
        new_conv1.weight.copy_(orig_conv1.weight.sum(dim=1, keepdim=True))
    model.conv1 = new_conv1

    model.fc = nn.Linear(model.fc.in_features, NUM_CLASSES)
    return model


# ==========================================
# DICOM -> NPY (256x256)
# ==========================================
def dicom_to_npy(dicom_path, npy_path):
    ds = pydicom.dcmread(dicom_path)
    img = ds.pixel_array.astype(np.float32)

    p_low, p_high = np.percentile(img, (1, 99))
    img = np.clip(img, p_low, p_high)

    if p_high > p_low:
        img = (img - p_low) / (p_high - p_low)
    else:
        img = np.zeros_like(img)

    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)
    np.save(npy_path, img.astype(np.float32))


# ==========================================
# DATAFRAME CON TEST SET FORZATO
# ==========================================
def build_dataframe():
    df = pd.read_excel(EXCEL_PATH)
    df = df.iloc[:, :2]
    df.columns = ["image_id", "label"]

    df = df[df["image_id"] <= 2306]
    df = df.dropna(subset=["label"])
    df["label"] = df["label"].astype(int)

    dicom_paths = []
    npy_paths = []

    for _, row in df.iterrows():
        image_id = int(row["image_id"])

        dicom_path = str(DICOM_DIR / f"{image_id}.dcm")
        npy_path = str(NPY_DIR / f"{image_id}.npy")

        if not os.path.exists(npy_path):
            if not os.path.exists(dicom_path):
                print(f"[ATTENZIONE] DICOM mancante: {dicom_path}")
                continue
            dicom_to_npy(dicom_path, npy_path)

        dicom_paths.append(dicom_path)
        npy_paths.append(npy_path)

    df_clean = df.iloc[: len(npy_paths)].copy()
    df_clean["dicom_path"] = dicom_paths
    df_clean["npy_path"] = npy_paths

    return df_clean.reset_index(drop=True)


# ==========================================
# DATASET + AUGMENTATION
# ==========================================
class MRIDataset(Dataset):
    def __init__(self, df, augment=False):
        self.df = df.reset_index(drop=True)
        self.augment = augment

        self.transform = T.Compose(
            [
                T.RandomHorizontalFlip(p=0.5),
                T.RandomVerticalFlip(p=0.5),
                T.RandomAffine(degrees=0, translate=(0.03, 0.03)),
            ]
        )

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img = np.load(row["npy_path"])
        img = torch.tensor(img).unsqueeze(0).float()

        if self.augment:
            img = self.transform(img)

        # Restituisce anche l'image_id per tracciarlo nei risultati
        return img, int(row["label"]), int(row["image_id"])


def create_fixed_dataloaders(df):
    if os.path.exists(ML_TEST_IDS_PATH):
        test_ids_df = pd.read_excel(ML_TEST_IDS_PATH)

        # Prende la prima colonna del file a prescindere dal nome e pulisce eventuali estensioni (.dcm / .DCM)
        raw_ids = test_ids_df.iloc[:, 0].astype(str)
        target_test_ids = [
            int(str(x).replace(".dcm", "").replace(".DCM", "").strip())
            for x in raw_ids
            if str(x).strip() != ""
        ]
    else:
        raise FileNotFoundError(
            f"[ERRORE] Non trovo il file con gli ID del test set ML in: {ML_TEST_IDS_PATH}."
        )

    test_df = df[df["image_id"].isin(target_test_ids)].copy()
    train_val_df = df[~df["image_id"].isin(target_test_ids)].copy()

    train_df, val_df = train_test_split(
        train_val_df, test_size=0.2, stratify=train_val_df["label"], random_state=42
    )

    print(f"Dimensione Train Set: {len(train_df)}")
    print(f"Dimensione Val Set:   {len(val_df)}")
    print(f"Dimensione Test Set (forzato da ML): {len(test_df)}")

    train_loader = DataLoader(
        MRIDataset(train_df, augment=True), batch_size=BATCH_SIZE, shuffle=True
    )
    val_loader = DataLoader(MRIDataset(val_df), batch_size=BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(MRIDataset(test_df), batch_size=BATCH_SIZE, shuffle=False)

    return train_loader, val_loader, test_loader


# ==========================================
# VALUTAZIONE ESTESA CON PREDIZIONI PER IMMAGINE
# ==========================================
def evaluate_and_save_predictions(model, loader, output_excel_path):
    model.eval()
    all_image_ids, all_labels, all_preds = [], [], []
    prob_classes = []

    with torch.no_grad():
        for imgs, labels, image_ids in loader:
            imgs = imgs.to(DEVICE)
            outputs = model(imgs)
            probs = torch.softmax(outputs, dim=1).cpu().numpy()
            preds = outputs.argmax(dim=1).cpu().numpy()

            all_image_ids.extend(image_ids.numpy())
            all_labels.extend(labels.numpy())
            all_preds.extend(preds)
            prob_classes.extend(probs)

    labels_arr = np.array(all_labels, dtype=np.int64)
    preds_arr = np.array(all_preds, dtype=np.int64)

    # Creazione del dataframe con le predizioni dettagliate per ogni singola immagine del test
    pred_df = pd.DataFrame(
        {
            "image_id": all_image_ids,
            "true_label": labels_arr,
            "predicted_label": preds_arr,
            "prob_class_0": [p[0] for p in prob_classes],
            "prob_class_1": [p[1] for p in prob_classes],
            "prob_class_2": [p[2] for p in prob_classes],
            "prob_class_3": [p[3] for p in prob_classes],
            "is_correct": labels_arr == preds_arr,
        }
    )

    pred_df.to_excel(output_excel_path, index=False)
    print(
        f"[INFO] Salvato il file dettagliato delle predizioni in: {output_excel_path}"
    )

    acc = float(np.mean(labels_arr == preds_arr))
    qwk = float(cohen_kappa_score(labels_arr, preds_arr, weights="quadratic"))
    adj_acc = float(np.sum(np.abs(labels_arr - preds_arr) <= 1) / len(labels_arr))
    cm = confusion_matrix(labels_arr, preds_arr)
    report = classification_report(
        labels_arr, preds_arr, output_dict=True, zero_division=0
    )

    return acc, qwk, adj_acc, cm, report, labels_arr


# ==========================================
# TRAINING & VALUTAZIONE COMPARATIVA
# ==========================================
def train_model():
    df = build_dataframe()
    print(f"Totale immagini caricate nel sistema: {len(df)}")

    train_loader, val_loader, test_loader = create_fixed_dataloaders(df)

    class_counts = df["label"].value_counts().sort_index().to_numpy(dtype=np.float32)
    weights_np = 1.0 / class_counts
    weights = torch.tensor(weights_np, dtype=torch.float).to(DEVICE)

    model = resnet18_mri().to(DEVICE)
    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=NUM_EPOCHS, eta_min=1e-6
    )

    best_val_acc = 0.0
    best_model_path = OUTPUT_DIR / "best_val_model.pth"
    last_model_path = OUTPUT_DIR / "last_epoch_model.pth"

    train_losses, train_accs = [], []
    val_losses, val_accs = [], []

    for epoch in range(NUM_EPOCHS):
        model.train()
        total_loss, total_correct, total_samples = 0.0, 0, 0

        for imgs, labels, _ in train_loader:
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)

            optimizer.zero_grad()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * imgs.size(0)
            total_correct += (outputs.argmax(1) == labels).sum().item()
            total_samples += imgs.size(0)

        train_loss = total_loss / total_samples
        train_acc = total_correct / total_samples

        model.eval()
        val_loss, val_correct, val_samples = 0.0, 0, 0

        with torch.no_grad():
            for imgs, labels, _ in val_loader:
                imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
                outputs = model(imgs)
                loss = criterion(outputs, labels)

                val_loss += loss.item() * imgs.size(0)
                val_correct += (outputs.argmax(1) == labels).sum().item()
                val_samples += imgs.size(0)

        val_loss /= val_samples
        val_acc = val_correct / val_samples

        train_losses.append(train_loss)
        train_accs.append(train_acc)
        val_losses.append(val_loss)
        val_accs.append(val_acc)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), best_model_path)
            print(
                f"Epoch [{epoch + 1:02d}/{NUM_EPOCHS}] "
                f"Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | "
                f"Val Loss: {val_loss:.4f} Acc: {val_acc:.4f} [RECORD SALVATO]"
            )
        else:
            print(
                f"Epoch [{epoch + 1:02d}/{NUM_EPOCHS}] "
                f"Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | "
                f"Val Loss: {val_loss:.4f} Acc: {val_acc:.4f}"
            )

        scheduler.step()

    torch.save(model.state_dict(), last_model_path)

    results_df = pd.DataFrame(
        {
            "epoch": list(range(1, NUM_EPOCHS + 1)),
            "train_loss": train_losses,
            "train_acc": train_accs,
            "val_loss": val_losses,
            "val_acc": val_accs,
        }
    )
    results_df.to_excel(OUTPUT_DIR / "training_results.xlsx", index=False)

    # Valutazione finale e salvataggio dei file dei risultati
    model.load_state_dict(torch.load(best_model_path))

    # Genera ed esporta test_predictions.xlsx
    preds_excel_path = OUTPUT_DIR / "test_predictions.xlsx"
    acc_best, qwk_best, adj_best, cm_best, rep_best, labels_arr = (
        evaluate_and_save_predictions(model, test_loader, preds_excel_path)
    )

    report_df = pd.DataFrame(rep_best).transpose()
    report_df.loc["QWK"] = [qwk_best, qwk_best, qwk_best, float(len(labels_arr))]
    report_df.loc["adjacent_acc_off1"] = [
        adj_best,
        adj_best,
        adj_best,
        float(len(labels_arr)),
    ]

    pd.DataFrame(cm_best).to_excel(OUTPUT_DIR / "confusion_matrix.xlsx", index=False)
    report_df.to_excel(OUTPUT_DIR / "classification_report.xlsx")
    torch.save(model.state_dict(), OUTPUT_DIR / "resnet_mri_artifacts.pth")

    print("\n==========================================")
    print("      RISULTATI TEST SET FINALI (FORZATO)")
    print("==========================================")
    print(f"Accuratezza Test:      {acc_best * 100:.2f}%")
    print(f"Quadratic Kappa (QWK): {qwk_best:.4f}")
    print(f"Adjacent Accuracy:     {adj_best * 100:.2f}%")
    print(f"File predizioni:       {preds_excel_path}")
    print("==========================================")


if __name__ == "__main__":
    train_model()
