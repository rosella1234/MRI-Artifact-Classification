import os
import cv2
import pydicom
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# ==============================================================================
# CONFIGURAZIONE DEI PERCORSI E PARAMETRI
# ==============================================================================
# Cartella contenente le 8 nuove immagini DICOM mai viste
VALIDATION_DIR = r"C:/Users/gibog/Desktop/tesi/dataset/DicomForValidation"

# Pesi del modello salvati al termine dell'addestramento della CNN
WEIGHTS_PATH = r"C:/Users/gibog/Desktop/tesi/output_codici/results_forced_test_60epochs_cnn_cop1_gemOptim_docker/resnet_mri_artifacts.pth"

# File Excel di output
OUTPUT_EXCEL = r"C:/Users/gibog/Desktop/tesi/output_codici/results_forced_test_60epochs_cnn_cop1_gemOptim_docker/Validation_CNN_Forced.xlsx"

IMG_SIZE = 256
NUM_CLASSES = 4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==============================================================================
# ARCHITETTURA DELLA RETE (IDENTICA AL TRAINING)
# ==============================================================================
def resnet18_mri():
    # Carica la struttura ResNet18
    model = models.resnet18(weights=None)

    # Converte il primo layer per accettare 1 canale in scala di grigi
    model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)

    # Sostituisce la testa di classificazione con 4 classi di output
    model.fc = nn.Linear(model.fc.in_features, NUM_CLASSES)

    return model

# ==============================================================================
# PREPROCESSING IDENTICO A dicom_to_npy
# ==============================================================================
def preprocess_dicom(dicom_path):
    ds = pydicom.dcmread(dicom_path)
    img = ds.pixel_array.astype(np.float32)

    # Clipping all'1% e 99% per normalizzare il contrasto dell'artefatto
    p_low, p_high = np.percentile(img, (1, 99))
    img = np.clip(img, p_low, p_high)

    if p_high > p_low:
        img = (img - p_low) / (p_high - p_low)
    else:
        img = np.zeros_like(img)

    # Ridimensionamento a 256x256
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)

    # Formattazione per PyTorch: dimensione (Batch, Canali, Altezza, Larghezza) -> (1, 1, 256, 256)
    tensor = torch.tensor(img, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
    return tensor

# ==============================================================================
# INFERENCE E SALVATAGGIO DEI RISULTATI
# ==============================================================================
def run_validation():
    print(f"Dispositivo in uso: {DEVICE}")
    print(f"Caricamento modello da: {WEIGHTS_PATH}")

    # Istanzia la rete e carica i pesi addestrati
    model = resnet18_mri()
    state_dict = torch.load(WEIGHTS_PATH, map_location=DEVICE)
    model.load_state_dict(state_dict)
    model.to(DEVICE)
    model.eval()  # Disattiva dropout e fissa i layer di Batch Normalization

    # Lettura robusta di tutti i file presenti nella cartella
    dicom_files = [
        f for f in os.listdir(VALIDATION_DIR)
        if os.path.isfile(os.path.join(VALIDATION_DIR, f))
    ]

    print(f"Trovate {len(dicom_files)} nuove immagini da classificare con la CNN.\n")

    results = []

    with torch.no_grad():  # Disattiva il calcolo dei gradienti per velocizzare l'esecuzione
        for file_name in dicom_files:
            dicom_path = os.path.join(VALIDATION_DIR, file_name)
            try:
                input_tensor = preprocess_dicom(dicom_path).to(DEVICE)

                # Forward pass
                outputs = model(input_tensor)

                # Calcolo delle probabilità tramite Softmax
                probabilities = F.softmax(outputs, dim=1).cpu().numpy()[0]
                predicted_class = int(np.argmax(probabilities))
                confidence = float(np.max(probabilities))

                results.append({
                    "filename": file_name,
                    "predicted_class": predicted_class,
                    "prob_class_0": probabilities[0],
                    "prob_class_1": probabilities[1],
                    "prob_class_2": probabilities[2],
                    "prob_class_3": probabilities[3],
                    "confidence": confidence
                })

                print(f"File: {file_name:<15} -> Classe: {predicted_class} (Confidenza: {confidence*100:.1f}%)")

            except Exception as e:
                print(f"Errore durante l'elaborazione del file {file_name}: {e}")

    # Creazione della cartella di output se non esiste
    os.makedirs(os.path.dirname(OUTPUT_EXCEL), exist_ok=True)

    # Salvataggio nel file Excel
    df_results = pd.DataFrame(results)
    df_results.to_excel(OUTPUT_EXCEL, index=False)
    print(f"\nPredizioni completate e salvate in: {OUTPUT_EXCEL}")

if __name__ == "__main__":
    run_validation()
